# Offline Protocol for Salarium Chain

## Emergency Minting Mechanism
If the system detects a verified offline state, a fallback reserve of 100,000 GRAIN tokens is minted to each wallet as a temporary barter baseline.

## Abuse Prevention
- Use QR-based physical verification codes
- Limit emergency mint claims to once per verified outage
