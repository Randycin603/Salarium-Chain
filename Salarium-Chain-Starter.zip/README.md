# Salarium Chain

An auditable, decentralized labor barter system powered by GRIT (proof-of-effort) and GRAIN (value) tokens.

