## Project Sprint Tasks

- [ ] Smart contract refinement
- [ ] GUI QR Proof integration
- [ ] Offline mint protocol logic
- [ ] Fiat conversion prototype
